package app.its.helper;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.WallpaperManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Inet4Address;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Replaces termux/server.js. Listens ONLY on 127.0.0.1:3000 (this phone). Minecraft connects with /connect (done by the addon itself),
 * the addon queues events as scoreboard names "ITS~type~k=v..." and we read + clear them.
 * The only connection to the internet is the optional country/city lookup (ipwho.is): off by default, needs a switch in the game AND in this app.
 */
public class CompanionService extends Service {
    static final int PORT = 3000;
    static volatile boolean running = false, connected = false;
    static final List<String> LOG = Collections.synchronizedList(new ArrayList<String>());
    static void log(String s) {
        LOG.add(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + "  " + s);
        while (LOG.size() > 40) LOG.remove(0);
    }

    interface Cb { void run(JSONObject body); }

    private ServerSocket server;
    private volatile Socket client;
    private volatile OutputStream out;
    private ScheduledExecutorService timer;
    private final Map<String, Cb> pending = new ConcurrentHashMap<>();
    private final Set<String> seen = Collections.synchronizedSet(new LinkedHashSet<String>());
    private NotificationManager nm;
    private int nid = 100;
    private JSONObject texts = new JSONObject();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile ScheduledExecutorService io;
    private final Runnable wpRestore = this::restoreWallpaper;

    // Settings sent by the game (/its:termux). Same bit order as OPTS in scripts/termux_bridge.js. Until they arrive (cfgKnown=false) the old behaviour is kept.
    static final int B_FILES = 0, B_NOTIFY = 1, B_DEVICE = 2, B_BATTERY = 3, B_TZ = 4, B_LOC = 5, B_IP = 6, B_NET = 7, B_CHAT = 8,
            B_LETTER = 9, B_KEYS = 10, B_END = 11, B_REPORT = 12, B_SCAN = 13, B_VIDEO = 14, B_CAMERA = 15, B_LOST = 16, B_POPUP = 17, B_SMILEY = 18, B_WALL = 19;
    private volatile boolean cfgKnown = false, cfgNormal = false;
    private volatile int cfgBits = 0;
    /** the switch is on in the game's form (ignores the mode) */
    private boolean rawBit(int b) { return !cfgKnown || ((cfgBits >> b) & 1) == 1; }
    /** allowed by the game's settings: Normal mode + switch on (or no settings received yet) */
    private boolean bit(int b) { return !cfgKnown || (cfgNormal && ((cfgBits >> b) & 1) == 1); }
    /** for features that are off by default: the game must have sent Normal mode with this switch on */
    private boolean opt(int b) { return cfgKnown && cfgNormal && ((cfgBits >> b) & 1) == 1; }
    private SharedPreferences prefs() { return getSharedPreferences("its", 0); }
    private boolean pref(String k, boolean def) { return prefs().getBoolean(k, def); }
    private void async(Runnable r) { try { ScheduledExecutorService e = io; if (e != null) e.execute(r); } catch (Exception e) { } }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("st", "Status", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel("ev", "Game events", NotificationManager.IMPORTANCE_HIGH));
        Notification n = new Notification.Builder(this, "st").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("ITS Helper is running").setContentText("Waiting for the game (this phone only)").build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        if (!running) {
            running = true;
            io = Executors.newScheduledThreadPool(3);
            if (pref("wp_pending", false)) { log("scary wallpaper was left on last time - restoring"); main.post(wpRestore); }
            try { texts = new JSONObject(read("popups.json")); } catch (Exception e) { log("popups.json: " + e.getMessage()); }
            new Thread(this::serve).start();
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        running = false; connected = false;
        stopTimer();
        try { if (client != null) client.close(); } catch (Exception e) { }
        try { if (server != null) server.close(); } catch (Exception e) { }
        ScheduledExecutorService e0 = io; io = null; if (e0 != null) e0.shutdownNow();
        main.removeCallbacksAndMessages(null);
        if (pref("wp_pending", false)) restoreWallpaper();
        log("Stopped");
    }

    // ------------------------------------------------------------------ socket
    private void serve() {
        try {
            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT));
            log("Ready: waiting for the game on 127.0.0.1:" + PORT);
            while (running) {
                final Socket s = server.accept();
                new Thread(() -> session(s)).start();
            }
        } catch (Exception e) {
            if (running) log("Cannot start: " + e.getMessage() + " (if Termux is open, close it first)");
        }
        running = false; connected = false;
        stopSelf();
    }

    private void session(Socket s) {
        try {
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream o = s.getOutputStream();
            ByteArrayOutputStream hb = new ByteArrayOutputStream();
            int c, st = 0;
            while (st < 4 && (c = in.read()) != -1) {
                hb.write(c);
                if (hb.size() > 8192) throw new IOException("header too large");
                st = (c == ((st % 2 == 0) ? '\r' : '\n')) ? st + 1 : (c == '\r' ? 1 : 0);
            }
            Matcher m = Pattern.compile("Sec-WebSocket-Key:\\s*(\\S+)", Pattern.CASE_INSENSITIVE).matcher(hb.toString("UTF-8"));
            if (!m.find()) { s.close(); return; }
            String acc = Base64.encodeToString(MessageDigest.getInstance("SHA-1")
                    .digest((m.group(1) + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes("UTF-8")), Base64.NO_WRAP);
            o.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + acc + "\r\n\r\n").getBytes("UTF-8"));
            o.flush();
            Socket old = client;
            client = s; out = o;
            if (old != null) try { old.close(); } catch (Exception e) { }
            onOpen();
            readLoop(in, s);
        } catch (Exception e) {
            // connection ended
        } finally {
            if (client == s) { client = null; out = null; connected = false; stopTimer(); log("Game disconnected"); }
            try { s.close(); } catch (Exception e) { }
        }
    }

    private void readLoop(InputStream in, Socket s) throws IOException {
        DataInputStream d = new DataInputStream(in);
        ByteArrayOutputStream msg = new ByteArrayOutputStream();
        while (running && !s.isClosed()) {
            int b0 = d.readUnsignedByte(), b1 = d.readUnsignedByte();
            boolean fin = (b0 & 0x80) != 0, masked = (b1 & 0x80) != 0;
            int op = b0 & 15;
            long len = b1 & 127;
            if (len == 126) len = d.readUnsignedShort(); else if (len == 127) len = d.readLong();
            if (len < 0 || len > 4000000) return;
            byte[] mk = new byte[4];
            if (masked) d.readFully(mk);
            byte[] p = new byte[(int) len];
            d.readFully(p);
            if (masked) for (int i = 0; i < p.length; i++) p[i] ^= mk[i & 3];
            if (op == 8) return;
            if (op == 9) { send(0xA, p); continue; }
            if (op == 1 || op == 0) {
                if (op == 1) msg.reset();
                msg.write(p);
                if (fin) onText(msg.toString("UTF-8"));
            }
        }
    }

    private synchronized void send(int op, byte[] p) {
        try {
            OutputStream o = out;
            if (o == null) return;
            ByteArrayOutputStream f = new ByteArrayOutputStream();
            f.write(0x80 | op);
            if (p.length < 126) f.write(p.length);
            else if (p.length < 65536) { f.write(126); f.write(p.length >> 8); f.write(p.length & 255); }
            else { f.write(127); for (int i = 7; i >= 0; i--) f.write((int) (((long) p.length >> (8 * i)) & 255)); }
            f.write(p);
            o.write(f.toByteArray());
            o.flush();
        } catch (Exception e) { }
    }

    // ------------------------------------------------------------------ Minecraft protocol
    private void command(String line, Cb cb) {
        try {
            final String id = UUID.randomUUID().toString();
            if (cb != null && timer != null) { pending.put(id, cb); timer.schedule(() -> { pending.remove(id); }, 10, TimeUnit.SECONDS); }
            JSONObject h = new JSONObject().put("version", 1).put("requestId", id).put("messagePurpose", "commandRequest").put("messageType", "commandRequest");
            JSONObject b = new JSONObject().put("origin", new JSONObject().put("type", "player")).put("commandLine", line).put("version", 1);
            send(1, new JSONObject().put("header", h).put("body", b).toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { }
    }

    private void onOpen() {
        connected = true;
        log("Game connected");
        stopTimer();
        timer = Executors.newSingleThreadScheduledExecutor();
        try {
            JSONObject h = new JSONObject().put("version", 1).put("requestId", UUID.randomUUID().toString()).put("messagePurpose", "subscribe").put("messageType", "commandRequest");
            send(1, new JSONObject().put("header", h).put("body", new JSONObject().put("eventName", "PlayerMessage")).toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { }
        tell("\u00a7a[ITS]\u00a7r ITS Helper connected.");
        command("scriptevent itx:sendcfg", null);   // the game answers with a "config" event (mode + switches)
        timer.scheduleWithFixedDelay(this::tick, 300, 1000, TimeUnit.MILLISECONDS);
    }

    private void stopTimer() { ScheduledExecutorService t = timer; timer = null; if (t != null) t.shutdownNow(); }

    private void tick() {
        try {
            command("scoreboard players set ws itx_ws 0", null);   // tells the addon a companion is alive
            command("tag @a remove ws_need", null);
            command("scoreboard players list", body -> {
                Matcher m = Pattern.compile("ITS~[A-Za-z0-9_.\\-=~]+").matcher(body.optString("statusMessage", ""));
                while (m.find()) {
                    String name = m.group();
                    command("scoreboard players reset " + name + " its_evt", null);
                    if (!seen.add(name)) continue;
                    if (seen.size() > 500) { synchronized (seen) { Iterator<String> it = seen.iterator(); it.next(); it.remove(); } }
                    final String ev = name;
                    async(() -> handle(ev));
                }
            });
        } catch (Exception e) { }
    }

    private void onText(String raw) {
        try {
            JSONObject m = new JSONObject(raw);
            JSONObject h = m.optJSONObject("header");
            if (h == null) return;
            String pu = h.optString("messagePurpose");
            if (pu.equals("commandResponse")) {
                Cb cb = pending.remove(h.optString("requestId"));
                JSONObject b = m.optJSONObject("body");
                if (cb != null) cb.run(b != null ? b : new JSONObject());
            } else if (pu.equals("event") && h.optString("eventName").equals("PlayerMessage")) {
                // game chat is passed straight back into the game (used for the story's codes). It is not stored or logged.
                JSONObject b = m.optJSONObject("body");
                if (b == null || !"chat".equals(b.optString("type"))) return;
                String msg = b.optString("message").replaceAll("[\\r\\n]+", " ").trim();
                String who = b.optString("sender").replaceAll("[\"\\\\\\r\\n]", "");
                if (msg.length() > 400) msg = msg.substring(0, 400);
                if (msg.isEmpty() || who.isEmpty() || msg.startsWith("/") || msg.startsWith("!its")) return;
                command("execute as @a[name=\"" + who + "\"] run scriptevent its:chatin " + msg, null);
            }
        } catch (Exception e) { }
    }

    // ------------------------------------------------------------------ events from the addon
    private void tell(String text) {
        command("tellraw @a {\"rawtext\":[{\"text\":\"" + text.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}]}", null);
    }

    private void skip(String what, String why) {
        log("Skipped " + what + ": " + why);
        tell("§e[ITS]§r " + what + " skipped: " + why);
    }

    private void handle(String name) {
        String[] parts = name.split("~");
        if (parts.length < 2) return;
        String type = parts[1];
        Map<String, String> a = new HashMap<>();
        for (int i = 2; i < parts.length; i++) { int k = parts[i].indexOf('='); if (k > 0) a.put(parts[i].substring(0, k), parts[i].substring(k + 1)); }
        boolean ru = "ru".equals(a.get("lang"));
        try {
            switch (type) {
                case "config": {
                    cfgNormal = "n".equals(a.get("m"));
                    try { cfgBits = Integer.parseInt(a.get("b")); } catch (Exception e) { cfgBits = 0; }
                    cfgKnown = true;
                    log("Settings from the game: " + (cfgNormal ? "Normal" : "Safe"));
                    tell("§a[ITS]§r ITS Helper got the settings: " + (cfgNormal ? "§6NORMAL" : "§aSAFE"));
                    pushGeo();
                    break;
                }
                case "popup": {
                    if (!bit(B_POPUP)) { log("popup skipped (switch off / Safe mode)"); break; }
                    JSONObject p = texts.getJSONObject("popups").optJSONObject(a.containsKey("k") ? a.get("k") : "");
                    if (p != null) alert(p.optString("title"), flat(p.opt("text")), null);
                    break;
                }
                case "lost":
                    if (!bit(B_LOST)) { log("lost message skipped (switch off / Safe mode)"); break; }
                    alert("LostPlayer303", texts.getJSONObject("lost").optString(a.containsKey("s") ? a.get("s") : "1", "LEAVE ME ALONE!"), null);
                    break;
                case "observation":
                    if (!bit(B_CAMERA)) { log("observation message skipped (switch off / Safe mode)"); break; }
                    alert(ru ? "Наблюдение" : "Observation",
                            ru ? "Я хочу посмотреть на тебя перед тем, как ты умрёшь" : "I want to look at you before you die", null);
                    break;
                case "letter":
                    if (!(bit(B_LETTER) && bit(B_FILES))) { log("letter skipped (switch off / Safe mode)"); break; }
                    save("its_files", ru ? "письмо_от_Айко.txt" : "letter_from_aiko.txt",
                            fill(read("files/letter_from_aiko." + (ru ? "ru" : "en") + ".txt"), a));
                    break;
                case "report": {
                    if (!(bit(B_REPORT) && bit(B_FILES))) { log("report skipped (switch off / Safe mode)"); break; }
                    String pl = (a.containsKey("p") ? a.get("p") : "Player").replaceAll("[\\\\/:*?\"<>|]", "_");
                    save("its_files", pl + "_report.txt", fill(read("files/report.en.txt"), a));
                    break;
                }
                case "key_files":
                    if (!(bit(B_KEYS) && bit(B_FILES))) { log("key files skipped (switch off / Safe mode)"); break; }
                    save("", "Key.txt", read("files/Key_root.txt"));
                    save("config", "Key.txt", read("files/Key_config.txt"));
                    save("logs", "Key.txt", read("files/Key_logs.txt"));
                    break;
                case "ending": {
                    if (!(bit(B_END) && bit(B_FILES))) { log("ending file skipped (switch off / Safe mode)"); break; }
                    String n = (a.containsKey("name") ? a.get("name") : "Ending").replaceAll("[^\\w-]", "");
                    save("its_endings", n + ".txt", read("files/ending_" + n + ".txt"));
                    break;
                }
                case "scan": runScan(); break;
                case "smiley":
                    if (!bit(B_SMILEY)) { log("drawing page skipped (switch off / Safe mode)"); break; }
                    if (!pref("p_paint", true)) { skip("Drawing page", "it is switched off in the ITS Helper app"); break; }
                    tell("§7[ITS]§r Opening \"Untitled - Paint\" on the phone...");
                    launch("Untitled - Paint", "Tap to open", 201, new Intent(this, PaintActivity.class));
                    break;
                case "video":
                    if (!opt(B_VIDEO)) { log("video skipped (switch off / Safe mode)"); break; }
                    if (!pref("p_video", false)) { skip("Video", "turn on \"Knock video\" in the ITS Helper app"); break; }
                    tell("§7[ITS]§r Opening Knock.mp4 on the phone...");
                    launch("Knock", "Tap to play", 202, new Intent(this, VideoActivity.class));
                    break;
                case "camera":
                    if (!opt(B_CAMERA)) { log("camera skipped (switch off / Safe mode)"); break; }
                    if (!pref("p_camera", false)) { skip("Camera", "turn on \"Open camera app\" in the ITS Helper app"); break; }
                    launch("Observation", "Tap to open the camera", 203, cameraIntent("android.media.action.STILL_IMAGE_CAMERA"), cameraIntent(MediaStore.ACTION_IMAGE_CAPTURE));
                    break;
                case "wallpaper": scaryWallpaper(); break;
                default: log("Not supported in this version: " + type);
            }
        } catch (Exception e) { log("Error (" + type + "): " + e.getMessage()); }
    }

    private String flat(Object o) {
        if (o instanceof JSONArray) { JSONArray ar = (JSONArray) o; StringBuilder sb = new StringBuilder(); for (int i = 0; i < ar.length(); i++) sb.append(i > 0 ? "\n" : "").append(ar.optString(i)); return sb.toString(); }
        return String.valueOf(o);
    }

    private Notification.Builder note(String title, String text) {
        return new Notification.Builder(this, "ev").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title)
                .setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true);
    }

    private void alert(String title, String text, PendingIntent tap) {
        if (!bit(B_NOTIFY)) { log("notification skipped (switch off / Safe mode): " + title); return; }
        log("Notification: " + title);
        Notification.Builder nb = note(title, text);
        if (tap != null) nb.setContentIntent(tap);
        nm.notify(nid++, nb.build());
    }

    /**
     * Opens one of our screens (or the camera app). Android 10+ only lets an app open a screen while another app (the game) is in front
     * if it has "Display over other apps". Without that permission the screen may be blocked, so a tappable notification is posted too.
     */
    private void launch(String title, String text, int rc, Intent... tries) {
        boolean overlay = Settings.canDrawOverlays(this);
        boolean ok = false;
        for (Intent i : tries) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            try { startActivity(i); ok = true; break; } catch (Exception e) { log("cannot open " + title + ": " + e.getMessage()); }
        }
        log("Opening: " + title + (ok ? "" : " (failed)") + (overlay ? "" : " - tip: allow \"Display over other apps\" in the app"));
        if (!overlay || !ok) {
            PendingIntent pi = PendingIntent.getActivity(this, rc, tries[0], PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            nm.notify(nid++, note(title, text).setContentIntent(pi).build());
        }
    }

    private Intent cameraIntent(String action) {
        Intent i = new Intent(action);
        i.putExtra("android.intent.extras.CAMERA_FACING", 1);
        i.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
        return i;
    }

    // ------------------------------------------------------------------ wallpaper (off by default; needs the game switch AND the switch in the app)
    private File wpBackup() { return new File(getFilesDir(), "wp_backup.img"); }

    private void scaryWallpaper() {
        if (!opt(B_WALL)) { log("wallpaper skipped (switch off / Safe mode)"); return; }
        if (!pref("p_wall", false)) { skip("Wallpaper", "turn on \"Scary wallpaper\" in the ITS Helper app"); return; }
        main.post(() -> {
            try {
                WallpaperManager wm = WallpaperManager.getInstance(this);
                if (!pref("wp_pending", false)) {   // already scary: only restart the 15 s, keep the first backup
                    File f = wpBackup();
                    f.delete();
                    try (ParcelFileDescriptor pfd = wm.getWallpaperFile(WallpaperManager.FLAG_SYSTEM)) {
                        if (pfd != null) try (FileInputStream in = new FileInputStream(pfd.getFileDescriptor()); FileOutputStream o = new FileOutputStream(f)) {
                            byte[] buf = new byte[8192]; int n;
                            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                        }
                    } catch (Exception e) { f.delete(); log("cannot read the current wallpaper - the phone's default one will be put back"); }
                    prefs().edit().putBoolean("wp_pending", true).apply();
                }
                Bitmap bm;
                try (InputStream in = getAssets().open("wallpaper_scary.png")) { bm = BitmapFactory.decodeStream(in); }
                wm.setBitmap(bm, null, false, WallpaperManager.FLAG_SYSTEM);
                log("Wallpaper: scary for 15 s");
                main.removeCallbacks(wpRestore);
                main.postDelayed(wpRestore, 15000);
            } catch (Exception e) { log("wallpaper failed: " + e.getMessage()); prefs().edit().putBoolean("wp_pending", false).apply(); }
        });
    }

    private void restoreWallpaper() {
        main.removeCallbacks(wpRestore);
        try {
            WallpaperManager wm = WallpaperManager.getInstance(this);
            File f = wpBackup();
            Bitmap bm = f.exists() && f.length() > 0 ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
            if (bm != null) wm.setBitmap(bm, null, false, WallpaperManager.FLAG_SYSTEM); else wm.clear(WallpaperManager.FLAG_SYSTEM);
            f.delete();
            log("Wallpaper: back to " + (bm != null ? "your own" : "the phone's default"));
        } catch (Exception e) { log("wallpaper restore failed: " + e.getMessage()); }
        prefs().edit().putBoolean("wp_pending", false).apply();
    }

    // ------------------------------------------------------------------ real phone data (each item needs the game switch AND the switch in the app; nothing is saved or sent anywhere)
    private static Map<String, String> geoCache;
    private static long geoAt;

    private static String clean(String v) {
        if (v == null) return "";
        v = v.replaceAll("[|=\"\\\\\\p{Cntrl}]", " ").trim();
        return v.length() > 40 ? v.substring(0, 40) : v;
    }

    /** ONE web request to ipwho.is (that website sees your IP). Only called when both switches are on. */
    private synchronized Map<String, String> lookup() {
        if (geoCache != null && System.currentTimeMillis() - geoAt < 300000) return geoCache;
        Map<String, String> r = new HashMap<>();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://ipwho.is/").openConnection();
            c.setConnectTimeout(5000); c.setReadTimeout(5000);
            c.setRequestProperty("User-Agent", "ITS-Helper");
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) { byte[] buf = new byte[4096]; int n; while ((n = in.read(buf)) > 0) b.write(buf, 0, n); }
            JSONObject j = new JSONObject(b.toString("UTF-8"));
            if (j.optBoolean("success", true)) {
                r.put("country", clean(j.optString("country"))); r.put("region", clean(j.optString("region"))); r.put("city", clean(j.optString("city")));
                r.put("ip", clean(j.optString("ip")));
                JSONObject cn = j.optJSONObject("connection");
                if (cn != null) r.put("isp", clean(cn.optString("isp")));
            }
        } catch (Exception e) { log("location lookup failed (offline?)"); }
        finally { if (c != null) c.disconnect(); }
        if (!r.isEmpty()) { geoCache = r; geoAt = System.currentTimeMillis(); }
        return r;
    }

    /** Sends the real country / region / city (and IP only if its switch is on) to the Angry Builder's signs, or clears it. */
    private void pushGeo() {
        async(() -> {
            try {
                if (!(opt(B_LOC) && pref("p_net", false))) { command("scriptevent itx:geo clear", null); return; }
                Map<String, String> g = lookup();
                List<String> kv = new ArrayList<>();
                for (String k : new String[]{"country", "region", "city"}) if (!g.getOrDefault(k, "").isEmpty()) kv.add(k + "=" + g.get(k));
                if (opt(B_IP) && !g.getOrDefault("ip", "").isEmpty()) kv.add("ip=" + g.get("ip"));
                command("scriptevent itx:geo " + (kv.isEmpty() ? "clear" : android.text.TextUtils.join("|", kv)), null);
            } catch (Exception e) { }
        });
    }

    private String localIp() {
        try {
            String any = null;
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress ia : Collections.list(ni.getInetAddresses())) {
                    if (ia instanceof Inet4Address && !ia.isLoopbackAddress()) {
                        if (ni.getName().startsWith("wlan")) return ia.getHostAddress();
                        if (any == null) any = ia.getHostAddress();
                    }
                }
            }
            return any;
        } catch (Exception e) { return null; }
    }

    private Map<String, String> profile() {
        Map<String, String> p = new HashMap<>();
        if (pref("dev", false)) {
            if (bit(B_DEVICE)) { p.put("device", Build.MANUFACTURER + " " + Build.MODEL); p.put("android", "Android " + Build.VERSION.RELEASE); }
            if (bit(B_TZ)) { p.put("timezone", TimeZone.getDefault().getID()); p.put("local_time", new SimpleDateFormat("HH:mm", Locale.US).format(new Date())); }
            if (bit(B_BATTERY)) {
                Intent bi = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (bi != null) { int lv = bi.getIntExtra("level", -1), sc = bi.getIntExtra("scale", 100); if (lv >= 0) p.put("battery", (lv * 100 / sc) + "%"); }
            }
        }
        if (pref("p_local", false) && opt(B_NET)) {   // local only, no web request
            String ip = localIp();
            if (ip != null) p.put("local_ip", ip);
            try {
                String car = ((TelephonyManager) getSystemService(TELEPHONY_SERVICE)).getNetworkOperatorName();
                if (car != null && !car.isEmpty()) p.put("carrier", clean(car));
            } catch (Exception e) { }
        }
        if (pref("p_net", false) && opt(B_LOC)) {
            Map<String, String> g = lookup();
            for (String k : new String[]{"country", "region", "city", "isp"}) if (!g.getOrDefault(k, "").isEmpty()) p.put(k, g.get(k));
            if (opt(B_IP) && !g.getOrDefault("ip", "").isEmpty()) p.put("ip", g.get("ip"));
        }
        return p;
    }

    /** The [SCAN] lines shown in the game chat during the Steam event. */
    private void runScan() {
        if (!rawBit(B_SCAN)) { log("scan skipped (switch off)"); return; }
        List<String> L = new ArrayList<>();
        L.add("§7[SCAN] Reading system information...");
        if (cfgKnown && !cfgNormal) { L.add("§7[SCAN] §fAccess denied."); L.add("§7[SCAN] §cI can still see you."); }
        else {
            Map<String, String> p = profile();
            if (p.containsKey("device")) L.add("§7[SCAN] Device: §f" + p.get("device") + " §7/ §f" + p.get("android"));
            if (p.containsKey("battery")) L.add("§7[SCAN] Battery: §f" + p.get("battery"));
            if (p.containsKey("timezone")) L.add("§7[SCAN] Local time: §f" + p.get("local_time") + " §7(" + p.get("timezone") + ")");
            if (p.containsKey("country")) {
                StringBuilder sb = new StringBuilder();
                for (String k : new String[]{"country", "region", "city"}) if (p.containsKey(k)) sb.append(sb.length() > 0 ? ", " : "").append(p.get(k));
                L.add("§7[SCAN] Location: §f" + sb);
            }
            if (p.containsKey("isp")) L.add("§7[SCAN] Provider: §f" + p.get("isp"));
            if (p.containsKey("ip")) L.add("§7[SCAN] IP: §f" + p.get("ip"));
            if (p.containsKey("local_ip")) L.add("§7[SCAN] Local address: §f" + p.get("local_ip") + (p.containsKey("carrier") ? " §7/ §f" + p.get("carrier") : ""));
            L.add("§7[SCAN] §cI can see you.");
        }
        ScheduledExecutorService e = io;
        if (e == null) return;
        for (int i = 0; i < L.size(); i++) {
            final String line = L.get(i);
            try { e.schedule(() -> tell(line), i * 2500L, TimeUnit.MILLISECONDS); } catch (Exception x) { }
        }
    }

    // ------------------------------------------------------------------ files
    /** Saves a .txt into Download/ITS[/sub] on this phone (no storage permission needed on Android 10+). */
    private void save(String sub, String fileName, String text) throws IOException {
        Files.save(this, sub, fileName, "text/plain", text.getBytes(StandardCharsets.UTF_8));
        log("Saved: Download/ITS/" + (sub.isEmpty() ? "" : sub + "/") + fileName);
        alert("New file", fileName + "  (Download/ITS)", null);
    }

    private String read(String asset) throws IOException {
        try (InputStream in = getAssets().open(asset)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return b.toString("UTF-8");
        }
    }

    /** Fills {player} {time} ... Real phone data is used ONLY for the items you switched on (in the app and in the game); the rest stays "unknown". */
    private String fill(String t, Map<String, String> a) {
        Map<String, String> p = profile();
        Map<String, String> v = new HashMap<>();
        v.put("player", a.containsKey("p") ? a.get("p") : "Player");
        v.put("time", (a.containsKey("min") ? a.get("min") : "0") + " min");
        for (String k : new String[]{"device", "android", "battery", "timezone", "local_time", "country", "region", "city", "isp", "ip", "local_ip", "carrier"})
            v.put(k, p.containsKey(k) ? p.get(k) : "unknown");
        Matcher m = Pattern.compile("\\{(\\w+)\\}").matcher(t);
        StringBuffer sb = new StringBuffer();
        while (m.find()) { String r = v.get(m.group(1)); m.appendReplacement(sb, Matcher.quoteReplacement(r == null ? m.group(0) : r)); }
        m.appendTail(sb);
        return sb.toString();
    }
}
