package app.its.helper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Replaces termux/server.js. Listens ONLY on 127.0.0.1:3000 (this phone). Minecraft connects with /connect (done by the addon itself),
 * the addon queues events as scoreboard names "ITS~type~k=v..." and we read + clear them. Nothing here opens a connection to the internet.
 */
public class CompanionService extends Service {
    static final int PORT = 3000;
    static volatile boolean running = false, connected = false;
    static final List<String> LOG = Collections.synchronizedList(new ArrayList<String>());
    static void log(String s) {
        LOG.add(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + "  " + s);
        while (LOG.size() > 40) LOG.remove(0);
    }

    interface Cb { void run(JSONObject body); }

    private ServerSocket server;
    private volatile Socket client;
    private volatile OutputStream out;
    private ScheduledExecutorService timer;
    private final Map<String, Cb> pending = new ConcurrentHashMap<>();
    private final Set<String> seen = Collections.synchronizedSet(new LinkedHashSet<String>());
    private NotificationManager nm;
    private int nid = 100;
    private JSONObject texts = new JSONObject();

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("st", "Status", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel("ev", "Game events", NotificationManager.IMPORTANCE_HIGH));
        Notification n = new Notification.Builder(this, "st").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("ITS Helper is running").setContentText("Waiting for the game (this phone only)").build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        if (!running) {
            running = true;
            try { texts = new JSONObject(read("popups.json")); } catch (Exception e) { log("popups.json: " + e.getMessage()); }
            new Thread(this::serve).start();
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        running = false; connected = false;
        stopTimer();
        try { if (client != null) client.close(); } catch (Exception e) { }
        try { if (server != null) server.close(); } catch (Exception e) { }
        log("Stopped");
    }

    // ------------------------------------------------------------------ socket
    private void serve() {
        try {
            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT));
            log("Ready: waiting for the game on 127.0.0.1:" + PORT);
            while (running) {
                final Socket s = server.accept();
                new Thread(() -> session(s)).start();
            }
        } catch (Exception e) {
            if (running) log("Cannot start: " + e.getMessage() + " (if Termux is open, close it first)");
        }
        running = false; connected = false;
        stopSelf();
    }

    private void session(Socket s) {
        try {
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream o = s.getOutputStream();
            ByteArrayOutputStream hb = new ByteArrayOutputStream();
            int c, st = 0;
            while (st < 4 && (c = in.read()) != -1) {
                hb.write(c);
                if (hb.size() > 8192) throw new IOException("header too large");
                st = (c == ((st % 2 == 0) ? '\r' : '\n')) ? st + 1 : (c == '\r' ? 1 : 0);
            }
            Matcher m = Pattern.compile("Sec-WebSocket-Key:\\s*(\\S+)", Pattern.CASE_INSENSITIVE).matcher(hb.toString("UTF-8"));
            if (!m.find()) { s.close(); return; }
            String acc = Base64.encodeToString(MessageDigest.getInstance("SHA-1")
                    .digest((m.group(1) + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes("UTF-8")), Base64.NO_WRAP);
            o.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + acc + "\r\n\r\n").getBytes("UTF-8"));
            o.flush();
            Socket old = client;
            client = s; out = o;
            if (old != null) try { old.close(); } catch (Exception e) { }
            onOpen();
            readLoop(in, s);
        } catch (Exception e) {
            // connection ended
        } finally {
            if (client == s) { client = null; out = null; connected = false; stopTimer(); log("Game disconnected"); }
            try { s.close(); } catch (Exception e) { }
        }
    }

    private void readLoop(InputStream in, Socket s) throws IOException {
        DataInputStream d = new DataInputStream(in);
        ByteArrayOutputStream msg = new ByteArrayOutputStream();
        while (running && !s.isClosed()) {
            int b0 = d.readUnsignedByte(), b1 = d.readUnsignedByte();
            boolean fin = (b0 & 0x80) != 0, masked = (b1 & 0x80) != 0;
            int op = b0 & 15;
            long len = b1 & 127;
            if (len == 126) len = d.readUnsignedShort(); else if (len == 127) len = d.readLong();
            if (len < 0 || len > 4000000) return;
            byte[] mk = new byte[4];
            if (masked) d.readFully(mk);
            byte[] p = new byte[(int) len];
            d.readFully(p);
            if (masked) for (int i = 0; i < p.length; i++) p[i] ^= mk[i & 3];
            if (op == 8) return;
            if (op == 9) { send(0xA, p); continue; }
            if (op == 1 || op == 0) {
                if (op == 1) msg.reset();
                msg.write(p);
                if (fin) onText(msg.toString("UTF-8"));
            }
        }
    }

    private synchronized void send(int op, byte[] p) {
        try {
            OutputStream o = out;
            if (o == null) return;
            ByteArrayOutputStream f = new ByteArrayOutputStream();
            f.write(0x80 | op);
            if (p.length < 126) f.write(p.length);
            else if (p.length < 65536) { f.write(126); f.write(p.length >> 8); f.write(p.length & 255); }
            else { f.write(127); for (int i = 7; i >= 0; i--) f.write((int) (((long) p.length >> (8 * i)) & 255)); }
            f.write(p);
            o.write(f.toByteArray());
            o.flush();
        } catch (Exception e) { }
    }

    // ------------------------------------------------------------------ Minecraft protocol
    private void command(String line, Cb cb) {
        try {
            final String id = UUID.randomUUID().toString();
            if (cb != null && timer != null) { pending.put(id, cb); timer.schedule(() -> { pending.remove(id); }, 10, TimeUnit.SECONDS); }
            JSONObject h = new JSONObject().put("version", 1).put("requestId", id).put("messagePurpose", "commandRequest").put("messageType", "commandRequest");
            JSONObject b = new JSONObject().put("origin", new JSONObject().put("type", "player")).put("commandLine", line).put("version", 1);
            send(1, new JSONObject().put("header", h).put("body", b).toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { }
    }

    private void onOpen() {
        connected = true;
        log("Game connected");
        stopTimer();
        timer = Executors.newSingleThreadScheduledExecutor();
        try {
            JSONObject h = new JSONObject().put("version", 1).put("requestId", UUID.randomUUID().toString()).put("messagePurpose", "subscribe").put("messageType", "commandRequest");
            send(1, new JSONObject().put("header", h).put("body", new JSONObject().put("eventName", "PlayerMessage")).toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { }
        command("tellraw @a {\"rawtext\":[{\"text\":\"\u00a7a[ITS]\u00a7r ITS Helper connected.\"}]}", null);
        timer.scheduleWithFixedDelay(this::tick, 300, 1000, TimeUnit.MILLISECONDS);
    }

    private void stopTimer() { ScheduledExecutorService t = timer; timer = null; if (t != null) t.shutdownNow(); }

    private void tick() {
        try {
            command("scoreboard players set ws itx_ws 0", null);   // tells the addon a companion is alive
            command("tag @a remove ws_need", null);
            command("scoreboard players list", body -> {
                Matcher m = Pattern.compile("ITS~[A-Za-z0-9_.\\-=~]+").matcher(body.optString("statusMessage", ""));
                while (m.find()) {
                    String name = m.group();
                    command("scoreboard players reset " + name + " its_evt", null);
                    if (!seen.add(name)) continue;
                    if (seen.size() > 500) { synchronized (seen) { Iterator<String> it = seen.iterator(); it.next(); it.remove(); } }
                    handle(name);
                }
            });
        } catch (Exception e) { }
    }

    private void onText(String raw) {
        try {
            JSONObject m = new JSONObject(raw);
            JSONObject h = m.optJSONObject("header");
            if (h == null) return;
            String pu = h.optString("messagePurpose");
            if (pu.equals("commandResponse")) {
                Cb cb = pending.remove(h.optString("requestId"));
                JSONObject b = m.optJSONObject("body");
                if (cb != null) cb.run(b != null ? b : new JSONObject());
            } else if (pu.equals("event") && h.optString("eventName").equals("PlayerMessage")) {
                // game chat is passed straight back into the game (used for the story's codes). It is not stored or logged.
                JSONObject b = m.optJSONObject("body");
                if (b == null || !"chat".equals(b.optString("type"))) return;
                String msg = b.optString("message").replaceAll("[\\r\\n]+", " ").trim();
                String who = b.optString("sender").replaceAll("[\"\\\\\\r\\n]", "");
                if (msg.length() > 400) msg = msg.substring(0, 400);
                if (msg.isEmpty() || who.isEmpty() || msg.startsWith("/") || msg.startsWith("!its")) return;
                command("execute as @a[name=\"" + who + "\"] run scriptevent its:chatin " + msg, null);
            }
        } catch (Exception e) { }
    }

    // ------------------------------------------------------------------ events from the addon
    private void handle(String name) {
        String[] parts = name.split("~");
        if (parts.length < 2) return;
        String type = parts[1];
        Map<String, String> a = new HashMap<>();
        for (int i = 2; i < parts.length; i++) { int k = parts[i].indexOf('='); if (k > 0) a.put(parts[i].substring(0, k), parts[i].substring(k + 1)); }
        boolean ru = "ru".equals(a.get("lang"));
        try {
            switch (type) {
                case "popup": {
                    JSONObject p = texts.getJSONObject("popups").optJSONObject(a.containsKey("k") ? a.get("k") : "");
                    if (p != null) alert(p.optString("title"), flat(p.opt("text")));
                    break;
                }
                case "lost":
                    alert("LostPlayer303", texts.getJSONObject("lost").optString(a.containsKey("s") ? a.get("s") : "1", "LEAVE ME ALONE!"));
                    break;
                case "observation":
                    alert(ru ? "\u041d\u0430\u0431\u043b\u044e\u0434\u0435\u043d\u0438\u0435" : "Observation",
                            ru ? "\u042f \u0445\u043e\u0447\u0443 \u043f\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u043d\u0430 \u0442\u0435\u0431\u044f \u043f\u0435\u0440\u0435\u0434 \u0442\u0435\u043c, \u043a\u0430\u043a \u0442\u044b \u0443\u043c\u0440\u0451\u0448\u044c" : "I want to look at you before you die");
                    break;
                case "letter":
                    save("its_files", ru ? "\u043f\u0438\u0441\u044c\u043c\u043e_\u043e\u0442_\u0410\u0439\u043a\u043e.txt" : "letter_from_aiko.txt",
                            fill(read("files/letter_from_aiko." + (ru ? "ru" : "en") + ".txt"), a));
                    break;
                case "report": {
                    String pl = (a.containsKey("p") ? a.get("p") : "Player").replaceAll("[\\\\/:*?\"<>|]", "_");
                    save("its_files", pl + "_report.txt", fill(read("files/report.en.txt"), a));
                    break;
                }
                case "key_files":
                    save("", "Key.txt", read("files/Key_root.txt"));
                    save("config", "Key.txt", read("files/Key_config.txt"));
                    save("logs", "Key.txt", read("files/Key_logs.txt"));
                    break;
                case "ending": {
                    String n = (a.containsKey("name") ? a.get("name") : "Ending").replaceAll("[^\\w-]", "");
                    save("its_endings", n + ".txt", read("files/ending_" + n + ".txt"));
                    break;
                }
                case "config": break;
                default: log("Not supported in this version: " + type);
            }
        } catch (Exception e) { log("Error (" + type + "): " + e.getMessage()); }
    }

    private String flat(Object o) {
        if (o instanceof JSONArray) { JSONArray ar = (JSONArray) o; StringBuilder sb = new StringBuilder(); for (int i = 0; i < ar.length(); i++) sb.append(i > 0 ? "\n" : "").append(ar.optString(i)); return sb.toString(); }
        return String.valueOf(o);
    }

    private void alert(String title, String text) {
        log("Notification: " + title);
        nm.notify(nid++, new Notification.Builder(this, "ev").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title)
                .setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).build());
    }

    /** Saves a .txt into Download/ITS[/sub] on this phone (no storage permission needed on Android 10+). */
    private void save(String sub, String fileName, String text) throws IOException {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
        v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ITS" + (sub.isEmpty() ? "" : "/" + sub));
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new IOException("cannot create " + fileName);
        try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(text.getBytes(StandardCharsets.UTF_8)); }
        log("Saved: Download/ITS/" + (sub.isEmpty() ? "" : sub + "/") + fileName);
        alert("New file", fileName + "  (Download/ITS)");
    }

    private String read(String asset) throws IOException {
        try (InputStream in = getAssets().open(asset)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return b.toString("UTF-8");
        }
    }

    /** Fills {player} {time} ... Device info is read ONLY when the user switched it on in the app. */
    private String fill(String t, Map<String, String> a) {
        boolean dev = getSharedPreferences("its", 0).getBoolean("dev", false);
        Map<String, String> v = new HashMap<>();
        v.put("player", a.containsKey("p") ? a.get("p") : "Player");
        v.put("time", (a.containsKey("min") ? a.get("min") : "0") + " min");
        String unk = "unknown", dm = unk, an = unk, bt = unk, tz = unk, lt = unk;
        if (dev) {
            dm = Build.MODEL; an = "Android " + Build.VERSION.RELEASE; tz = TimeZone.getDefault().getID();
            lt = new SimpleDateFormat("HH:mm", Locale.US).format(new Date());
            Intent bi = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bi != null) { int lv = bi.getIntExtra("level", -1), sc = bi.getIntExtra("scale", 100); if (lv >= 0) bt = (lv * 100 / sc) + "%"; }
        }
        v.put("device", dm); v.put("android", an); v.put("battery", bt); v.put("timezone", tz); v.put("local_time", lt);
        v.put("country", unk); v.put("city", unk);
        Matcher m = Pattern.compile("\\{(\\w+)\\}").matcher(t);
        StringBuffer sb = new StringBuffer();
        while (m.find()) { String r = v.get(m.group(1)); m.appendReplacement(sb, Matcher.quoteReplacement(r == null ? m.group(0) : r)); }
        m.appendTail(sb);
        return sb.toString();
    }
}
