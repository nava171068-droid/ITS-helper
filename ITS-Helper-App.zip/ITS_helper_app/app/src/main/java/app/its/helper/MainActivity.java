package app.its.helper;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.os.Looper;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    // Change this to the real address of the public source code (GitHub repository) of this app.
    static final String SOURCE_URL = "https://github.com/nava171068-droid/ITS-helper";

    // Everything this app does is written here in plain words. If the code ever changes what it does, change this text too.
    static final String[][] INFO = {
        {"What is this app?",
         "A small helper for the Minecraft addon Inside The System (ITS). It replaces Termux: it receives signals from the game running on this same phone and shows them on the phone."},
        {"What it does (only when the game asks)",
         "• Shows notifications (story messages)\n"
       + "• Creates text files (.txt: letters, report, Key files, endings) in the Download/ITS folder. You can open and delete them in your file manager\n"
       + "• Chat typed in the game passes through the app and goes straight back into the game (used for in-story codes). It is not stored\n"
       + "• Opens a small drawing page (\"Untitled - Paint\") inside this app. It works offline. You can switch it off below\n"
       + "• Shows the [SCAN] lines in the game chat during the Steam event (only with the data you allowed below)"},
        {"Extra features (all OFF by default, you choose below)",
         "Each one runs only if you turn it on in this app AND in the game's /its:termux form (Normal mode):\n"
       + "• Knock video: plays a short scary clip full screen\n"
       + "• Open camera app: only OPENS the camera app, it takes no photo and saves nothing\n"
       + "• Scary wallpaper: changes your home-screen wallpaper for 15 seconds, then puts it back. If Android does not let the app read your current wallpaper, it puts back the phone's default wallpaper instead\n"
       + "• Device info (model / Android / battery / time zone): written into the report/letter and shown in [SCAN]. Never leaves your phone\n"
       + "• Local network info (Wi-Fi address inside your home network, mobile carrier name): same, never leaves your phone\n"
       + "• Country / city from IP: makes ONE request to the website ipwho.is (that website sees your IP address) and shows the answer in your game. The real IP address is shown only if you also switch that on in the game"},
        {"What it does NOT do",
         "• Sends no data about you to any server of ours: no server, no account, no ads, no analytics. The only internet request is the optional country/city lookup above\n"
       + "• Does not access photos, videos, contacts, SMS, precise location or microphone. It cannot take pictures or record video\n"
       + "• Does not delete or modify your other files\n"
       + "• Does not start by itself when the phone boots, and stops as soon as you press Stop"},
        {"About the \"Internet\" permission",
         "Android requires it to open a socket on the phone itself. That socket is bound to 127.0.0.1 (this phone only); other devices cannot connect to it. The only other use is the optional country/city lookup, which is OFF until you switch it on."},
        {"About \"Display over other apps\"",
         "Optional. Android does not let an app open a screen while another app (Minecraft) is in front. With this permission the app can open the video, drawing page or camera by itself. Without it you get a notification to tap instead. You can remove it any time in Android settings."},
        {"Is it a virus?",
         "No, it is not a virus or malware. It does only what is written above, and the full source code is open to inspect.\n"
       + "If your phone warns that the app is unknown, that is because it does not come from the Play Store. It does not mean it is dangerous, but only download it from the creator's official link."},
        {"Your data",
         "Files the app creates stay on your phone and go nowhere unless you share them yourself. You can uninstall the app any time (files in Download/ITS must be deleted yourself in your file manager)."},
    };

    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("its", 0);
        String pf = sp.getString("platform", "");
        if (pf.equals("ios")) showIos();
        else if (pf.equals("android")) { if (sp.getBoolean("ok3", false)) showMain(); else showInfo(true); }
        else showPlatform();
    }

    // ------------------------------------------------------------------ screen 0: choose Android or iOS
    private void showPlatform() {
        LinearLayout l = page();
        text(l, "ITS Helper", 26, true);
        text(l, "Which device do you play Minecraft on?", 18, true);
        button(l, "Android").setOnClickListener(v -> {
            sp.edit().putString("platform", "android").apply();
            if (sp.getBoolean("ok3", false)) showMain(); else showInfo(true);
        });
        button(l, "iOS (iPhone / iPad)").setOnClickListener(v -> showIos());
    }

    // ------------------------------------------------------------------ iOS: read the limitations first
    private void showIos() {
        LinearLayout l = page();
        text(l, "iOS (iPhone / iPad)", 26, true);
        text(l, "Please read the limitations first", 16, false);
        text(l, "The addon itself works on iOS, but this helper app does not. iOS does not allow these things:", 15, false);
        text(l, "\u2022 No background service: iOS pauses an app a few seconds after you leave it. When you open Minecraft the helper stops, so the game can never stay connected to it.\n"
              + "\u2022 No files written to your phone: letters, Key files, endings and the report cannot be saved as .txt files like on Android.\n"
              + "\u2022 No scary wallpaper, no popups or video over Minecraft, no opening the camera by itself.\n"
              + "\u2022 No real device / network / country info: the original's fake data is used instead.\n"
              + "\u2022 This helper app is an Android app (APK). It cannot be installed on an iPhone or iPad.", 15, false);
        text(l, "What you get on iOS", 17, true);
        text(l, "Play the addon without the helper. Everything stays inside the game: letters, endings and the report appear as books / forms in the game, and popups use in-game titles and sounds. The story is the same, only the effects outside the game are missing.", 15, false);
        text(l, "How to play on iOS", 17, true);
        text(l, "1) Install the addon in Minecraft as usual.\n2) Do NOT use /connect and do not run /its:termux.\n3) Just play. The addon switches to its in-game mode when no helper is connected.", 15, false);
        button(l, "I understand").setOnClickListener(v -> {
            sp.edit().putString("platform", "ios").apply();
            showIos();
        });
        button(l, "Back").setOnClickListener(v -> showPlatform());
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private LinearLayout page() {
        h.removeCallbacksAndMessages(null);
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(40), dp(20), dp(40));
        sv.addView(l);
        setContentView(sv);
        return l;
    }

    private TextView text(LinearLayout l, String s, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(0xFF222222);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        v.setPadding(0, dp(6), 0, dp(6));
        l.addView(v);
        return v;
    }

    private CheckBox check(LinearLayout l, final String key, boolean def, String label) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setChecked(sp.getBoolean(key, def));
        c.setOnCheckedChangeListener((v, on) -> sp.edit().putBoolean(key, on).apply());
        l.addView(c);
        return c;
    }

    private Button button(LinearLayout l, String s) { Button b = new Button(this); b.setText(s); l.addView(b); return b; }

    // ------------------------------------------------------------------ screen 1: what this app does
    private void showInfo(final boolean first) {
        LinearLayout l = page();
        text(l, "ITS Helper", 26, true);
        text(l, "Read first: what this app does on your phone", 16, false);
        for (String[] sec : INFO) { text(l, sec[0], 17, true); text(l, sec[1], 15, false); }
        Button src = button(l, "View source code (check it yourself)");
        src.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SOURCE_URL))));
        if (first) {
            final CheckBox cb = new CheckBox(this);
            cb.setText("I have read and understand");
            l.addView(cb);
            final Button go = button(l, "Get started");
            go.setEnabled(false);
            cb.setOnCheckedChangeListener((c, on) -> go.setEnabled(on));
            go.setOnClickListener(v -> { sp.edit().putBoolean("ok3", true).apply(); showMain(); });
        } else {
            button(l, "Back").setOnClickListener(v -> showMain());
        }
    }

    // ------------------------------------------------------------------ screen 2: start / stop
    private void showMain() {
        LinearLayout l = page();
        text(l, "ITS Helper", 26, true);
        final TextView status = text(l, "", 18, true);
        final Button toggle = button(l, "");
        toggle.setOnClickListener(v -> {
            Intent svc = new Intent(this, CompanionService.class);
            if (CompanionService.running) { stopService(svc); }
            else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                startForegroundService(svc);
            }
        });
        text(l, "Extra features (off = never runs)", 17, true);
        check(l, "dev", false, "Device info (model / Android / battery / time zone) - stays on this phone");
        check(l, "p_local", false, "Local network info (Wi-Fi address, carrier name) - stays on this phone");
        check(l, "p_net", false, "Country / city from IP - makes ONE request to ipwho.is");
        check(l, "p_paint", true, "Drawing page (\"Untitled - Paint\")");
        check(l, "p_video", false, "Knock video");
        check(l, "p_camera", false, "Open camera app (takes no photo)");
        check(l, "p_wall", false, "Scary wallpaper for 15 s (then put back)");
        text(l, "These also need to be switched on in the game: /its:termux, Normal mode.", 13, false);
        final TextView ovl = text(l, "", 14, false);
        button(l, "Allow \"Display over other apps\"").setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        text(l, "How to use", 17, true);
        text(l, "1) Press Start and allow notifications.\n2) Open Minecraft (keep this app running). In the world turn on Cheats and Beta APIs (Experiments), and in Settings turn OFF \"Require Encrypted WebSockets\".\n"
              + "3) Enter the world and type:  /connect 127.0.0.1:3000   (older versions: /wsserver 127.0.0.1:3000)\n"
              + "4) Wait for the [ITS] message in chat, then type /its:termux and choose Normal mode.\n5) Files appear in Download/ITS", 15, false);
        text(l, "Recent log", 17, true);
        final TextView log = text(l, "", 12, false);
        log.setTypeface(Typeface.MONOSPACE);
        button(l, "Read app info again").setOnClickListener(v -> showInfo(false));
        button(l, "Change device (Android / iOS)").setOnClickListener(v -> showPlatform());
        h.post(new Runnable() {
            @Override public void run() {
                boolean on = CompanionService.running;
                status.setText(on ? (CompanionService.connected ? "\u25cf Running - game connected" : "\u25cf Running - waiting for the game") : "\u25cb Stopped");
                toggle.setText(on ? "Stop" : "Start");
                ovl.setText(Settings.canDrawOverlays(MainActivity.this) ? "Display over other apps: allowed" : "Display over other apps: not allowed (you will get a notification to tap)");
                synchronized (CompanionService.LOG) {
                    int from = Math.max(0, CompanionService.LOG.size() - 12);
                    log.setText(android.text.TextUtils.join("\n", CompanionService.LOG.subList(from, CompanionService.LOG.size())));
                }
                h.postDelayed(this, 1000);
            }
        });
    }
}
