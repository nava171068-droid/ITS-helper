package app.its.helper;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    // Change this to the real address of the public source code (GitHub repository) of this app.
    static final String SOURCE_URL = "https://github.com/nava171068-droid/ITS-helper";

    // Everything this app does is written here in plain words. If the code ever changes what it does, change this text too.
    static final String[][] INFO = {
        {"What is this app?",
         "A small helper for the Minecraft addon Inside The System (ITS). It replaces Termux: it receives signals from the game running on this same phone and shows them on the phone."},
        {"What it does (only when the game asks)",
         "\u2022 Shows notifications (story messages)\n"
       + "\u2022 Creates text files (.txt: letters, report, Key files, endings) in the Download/ITS folder. You can open and delete them in your file manager\n"
       + "\u2022 Chat typed in the game passes through the app and goes straight back into the game (used for in-story codes). It is not stored\n"
       + "\u2022 If you tick \"Add device info\" (off by default), the app reads your phone model, Android version, battery level and time zone, only to write them into the report file on your phone"},
        {"What it does NOT do",
         "\u2022 Sends no data off your phone: the code has no connection to the internet, no server, no account, no ads, no analytics\n"
       + "\u2022 Does not access photos, videos, contacts, SMS, location, camera or microphone\n"
       + "\u2022 Does not change your wallpaper or delete/modify other files (this version)\n"
       + "\u2022 Does not start by itself when the phone boots, and stops as soon as you press Stop"},
        {"About the \"Internet\" permission",
         "The app declares this permission because Android requires it even to open a socket on the phone itself. The socket is bound to 127.0.0.1 (this phone only); other devices cannot connect to it."},
        {"Is it a virus?",
         "No, it is not a virus or malware. It does only what is written above, and the full source code is open to inspect.\n"
       + "If your phone warns that the app is unknown, that is because it does not come from the Play Store. It does not mean it is dangerous, but only download it from the creator's official link."},
        {"Your data",
         "Files the app creates stay on your phone and go nowhere unless you share them yourself. You can uninstall the app any time (files in Download/ITS must be deleted yourself in your file manager)."},
    };

    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("its", 0);
        if (sp.getBoolean("ok", false)) showMain(); else showInfo(true);
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private LinearLayout page() {
        h.removeCallbacksAndMessages(null);
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(40), dp(20), dp(40));
        sv.addView(l);
        setContentView(sv);
        return l;
    }

    private TextView text(LinearLayout l, String s, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(0xFF222222);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        v.setPadding(0, dp(6), 0, dp(6));
        l.addView(v);
        return v;
    }

    private Button button(LinearLayout l, String s) { Button b = new Button(this); b.setText(s); l.addView(b); return b; }

    // ------------------------------------------------------------------ screen 1: what this app does
    private void showInfo(final boolean first) {
        LinearLayout l = page();
        text(l, "ITS Helper", 26, true);
        text(l, "Read first: what this app does on your phone", 16, false);
        for (String[] sec : INFO) { text(l, sec[0], 17, true); text(l, sec[1], 15, false); }
        Button src = button(l, "View source code (check it yourself)");
        src.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SOURCE_URL))));
        if (first) {
            final CheckBox cb = new CheckBox(this);
            cb.setText("I have read and understand");
            l.addView(cb);
            final Button go = button(l, "Get started");
            go.setEnabled(false);
            cb.setOnCheckedChangeListener((c, on) -> go.setEnabled(on));
            go.setOnClickListener(v -> { sp.edit().putBoolean("ok", true).apply(); showMain(); });
        } else {
            button(l, "Back").setOnClickListener(v -> showMain());
        }
    }

    // ------------------------------------------------------------------ screen 2: start / stop
    private void showMain() {
        LinearLayout l = page();
        text(l, "ITS Helper", 26, true);
        final TextView status = text(l, "", 18, true);
        final Button toggle = button(l, "");
        toggle.setOnClickListener(v -> {
            Intent svc = new Intent(this, CompanionService.class);
            if (CompanionService.running) { stopService(svc); }
            else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                startForegroundService(svc);
            }
        });
        final CheckBox dev = new CheckBox(this);
        dev.setText("Add device info (model / Android / battery / time zone) to the report file - stays on this phone");
        dev.setChecked(sp.getBoolean("dev", false));
        dev.setOnCheckedChangeListener((c, on) -> sp.edit().putBoolean("dev", on).apply());
        l.addView(dev);
        text(l, "How to use", 17, true);
        text(l, "1) Press Start and allow notifications.\n2) Open Minecraft (keep this app running). In the world turn on Cheats, and in Settings turn OFF \"Require Encrypted WebSockets\".\n"
              + "3) Enter the world, wait for the [ITS] message in chat, then type /its:termux and choose Normal mode.\n4) Files appear in Download/ITS", 15, false);
        text(l, "Recent log", 17, true);
        final TextView log = text(l, "", 12, false);
        log.setTypeface(Typeface.MONOSPACE);
        button(l, "Read app info again").setOnClickListener(v -> showInfo(false));
        h.post(new Runnable() {
            @Override public void run() {
                boolean on = CompanionService.running;
                status.setText(on ? (CompanionService.connected ? "\u25cf Running - game connected" : "\u25cf Running - waiting for the game") : "\u25cb Stopped");
                toggle.setText(on ? "Stop" : "Start");
                synchronized (CompanionService.LOG) {
                    int from = Math.max(0, CompanionService.LOG.size() - 12);
                    log.setText(android.text.TextUtils.join("\n", CompanionService.LOG.subList(from, CompanionService.LOG.size())));
                }
                h.postDelayed(this, 1000);
            }
        });
    }
}
