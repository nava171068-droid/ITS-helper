package app.its.helper;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.IOException;
import java.io.OutputStream;

/** Saves a file into Download/ITS[/sub] on this phone (no storage permission needed on Android 10+). */
final class Files {
    private Files() { }

    static void save(Context c, String sub, String fileName, String mime, byte[] data) throws IOException {
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ITS" + (sub.isEmpty() ? "" : "/" + sub));
        Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new IOException("cannot create " + fileName);
        try (OutputStream o = c.getContentResolver().openOutputStream(u)) { o.write(data); }
    }
}
