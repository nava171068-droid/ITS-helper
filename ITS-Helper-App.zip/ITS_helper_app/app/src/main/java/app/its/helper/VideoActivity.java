package app.its.helper;

import android.app.Activity;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.VideoView;

/** Plays the Knock clip (res/raw/knock.mp4) full screen, then closes by itself. Back button closes it too. Nothing is downloaded. */
public class VideoActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        VideoView vv = new VideoView(this);
        root.addView(vv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        setContentView(root);
        int id = getResources().getIdentifier("knock", "raw", getPackageName());
        vv.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + id));
        vv.setOnPreparedListener(mp -> vv.start());
        vv.setOnCompletionListener(mp -> finish());
        vv.setOnErrorListener((mp, what, extra) -> { finish(); return true; });
    }
}
