package app.its.helper;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

/** "Untitled - Paint": the original opens a Paint window that draws a smiley. This shows the same drawing page (assets/paint.html) inside the app. Fully offline. */
public class PaintActivity extends Activity {
    private WebView web;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setBlockNetworkLoads(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        web.setBackgroundColor(0xFF808080);
        web.addJavascriptInterface(new Bridge(), "ITSApp");
        setContentView(web);
        web.loadUrl("file:///android_asset/paint.html");
    }

    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("ITSApp"); web.destroy(); }
        super.onDestroy();
    }

    public class Bridge {
        @JavascriptInterface public void close() { runOnUiThread(() -> finish()); }

        @JavascriptInterface public void savePng(String dataUrl) {
            try {
                int k = dataUrl.indexOf(',');
                byte[] png = Base64.decode(dataUrl.substring(k + 1), Base64.DEFAULT);
                Files.save(PaintActivity.this, "", "Untitled_" + System.currentTimeMillis() + ".png", "image/png", png);
                runOnUiThread(() -> Toast.makeText(PaintActivity.this, "Saved: Download/ITS", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(PaintActivity.this, "Cannot save: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }
    }
}
