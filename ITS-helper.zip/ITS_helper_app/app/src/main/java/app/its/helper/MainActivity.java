package app.its.helper;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    // Change this to the real address of the public source code (GitHub repository) of this app.
    static final String SOURCE_URL = "https://github.com/nava171068-droid/ITS-helper";

    // Everything this app does is written here in plain words. If the code ever changes what it does, change this text too.
    static final String[][] INFO = {
        {"แอปนี้คืออะไร",
         "ตัวช่วยเล็กๆ สำหรับแอดออน Inside The System (ITS) ของ Minecraft ใช้แทน Termux\n"
       + "รับสัญญาณจากเกมที่เล่นอยู่ในมือถือเครื่องนี้ แล้วแสดงผลบนมือถือ"},
        {"แอปทำอะไรบ้าง (เมื่อเกมสั่งเท่านั้น)",
         "• ขึ้นการแจ้งเตือน (ข้อความในเนื้อเรื่อง)\n"
       + "• สร้างไฟล์ข้อความ .txt (จดหมาย รายงาน ไฟล์ Key ตอนจบ) ในโฟลเดอร์ Download/ITS คุณเปิดดูและลบเองได้ใน File Manager\n"
       + "• ข้อความที่พิมพ์ในแชทเกมจะผ่านแอปเพื่อส่งกลับเข้าเกม (ใช้กับรหัสในเรื่อง) ไม่ถูกบันทึก\n"
       + "• ถ้าคุณติ๊ก \"ใส่ข้อมูลเครื่อง\" (ปิดอยู่ตอนแรก) แอปจะอ่านรุ่นมือถือ เวอร์ชัน Android แบตเตอรี่ เขตเวลา เพื่อเขียนลงในไฟล์รายงานบนมือถือคุณเท่านั้น"},
        {"แอปไม่ทำอะไร",
         "• ไม่ส่งข้อมูลใดๆ ออกจากมือถือ: โค้ดไม่มีส่วนเชื่อมต่อออกอินเทอร์เน็ต ไม่มีเซิร์ฟเวอร์ ไม่มีบัญชี ไม่มีโฆษณา ไม่มีตัววิเคราะห์\n"
       + "• ไม่เข้าถึงรูป วิดีโอ รายชื่อผู้ติดต่อ SMS ตำแหน่ง กล้อง หรือไมโครโฟน\n"
       + "• ไม่เปลี่ยนวอลเปเปอร์ ไม่ลบหรือแก้ไฟล์อื่น (เวอร์ชันนี้)\n"
       + "• ไม่เริ่มเองตอนเปิดเครื่อง และหยุดทันทีเมื่อคุณกดหยุด"},
        {"เรื่องสิทธิ์ \"อินเทอร์เน็ต\"",
         "แอปประกาศสิทธิ์นี้เพราะ Android บังคับ แม้แต่การเปิดช่องรับสัญญาณในเครื่องเอง แอปผูกช่องไว้ที่ 127.0.0.1 (เครื่องนี้เท่านั้น) อุปกรณ์อื่นต่อเข้ามาไม่ได้"},
        {"เป็นไวรัสไหม",
         "ไม่ใช่ไวรัสหรือมัลแวร์ แอปทำเฉพาะสิ่งที่เขียนไว้ข้างบน และซอร์สโค้ดทั้งหมดเปิดให้ตรวจ\n"
       + "ถ้ามือถือเตือนว่าเป็นแอปที่ไม่รู้จัก เป็นเพราะไม่ได้มาจาก Play Store ไม่ได้แปลว่าอันตราย แต่ควรโหลดจากลิงก์ทางการของผู้สร้างเท่านั้น"},
        {"ข้อมูลของคุณ",
         "ไฟล์ที่แอปสร้างอยู่ในมือถือคุณ จะไม่ไปที่ไหนถ้าคุณไม่แชร์เอง ถอนการติดตั้งแอปได้ทุกเมื่อ (ไฟล์ใน Download/ITS ต้องลบเองใน File Manager)"},
    };

    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("its", 0);
        if (sp.getBoolean("ok", false)) showMain(); else showInfo(true);
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private LinearLayout page() {
        h.removeCallbacksAndMessages(null);
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(40), dp(20), dp(40));
        sv.addView(l);
        setContentView(sv);
        return l;
    }

    private TextView text(LinearLayout l, String s, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(size); v.setTextColor(0xFF222222);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        v.setPadding(0, dp(6), 0, dp(6));
        l.addView(v);
        return v;
    }

    private Button button(LinearLayout l, String s) { Button b = new Button(this); b.setText(s); l.addView(b); return b; }

    // ------------------------------------------------------------------ screen 1: what this app does
    private void showInfo(final boolean first) {
        LinearLayout l = page();
        text(l, "ITS Helper", 26, true);
        text(l, "อ่านก่อนใช้งาน: แอปนี้ทำอะไรกับมือถือคุณ", 16, false);
        for (String[] sec : INFO) { text(l, sec[0], 17, true); text(l, sec[1], 15, false); }
        Button src = button(l, "ดูซอร์สโค้ด (ตรวจสอบเองได้)");
        src.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(SOURCE_URL))));
        if (first) {
            final CheckBox cb = new CheckBox(this);
            cb.setText("ฉันอ่านและเข้าใจแล้ว");
            l.addView(cb);
            final Button go = button(l, "เริ่มใช้งาน");
            go.setEnabled(false);
            cb.setOnCheckedChangeListener((c, on) -> go.setEnabled(on));
            go.setOnClickListener(v -> { sp.edit().putBoolean("ok", true).apply(); showMain(); });
        } else {
            button(l, "กลับ").setOnClickListener(v -> showMain());
        }
    }

    // ------------------------------------------------------------------ screen 2: start / stop
    private void showMain() {
        LinearLayout l = page();
        text(l, "ITS Helper", 26, true);
        final TextView status = text(l, "", 18, true);
        final Button toggle = button(l, "");
        toggle.setOnClickListener(v -> {
            Intent svc = new Intent(this, CompanionService.class);
            if (CompanionService.running) { stopService(svc); }
            else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                startForegroundService(svc);
            }
        });
        final CheckBox dev = new CheckBox(this);
        dev.setText("ใส่ข้อมูลเครื่อง (รุ่น/Android/แบต/เขตเวลา) ในไฟล์รายงาน — อยู่ในมือถือเท่านั้น");
        dev.setChecked(sp.getBoolean("dev", false));
        dev.setOnCheckedChangeListener((c, on) -> sp.edit().putBoolean("dev", on).apply());
        l.addView(dev);
        text(l, "วิธีใช้", 17, true);
        text(l, "1) กด \"เริ่ม\" แล้วอนุญาตการแจ้งเตือน\n2) เปิด Minecraft (อย่าปิดแอปนี้) เปิด Cheats ในโลก และปิด \"Require Encrypted WebSockets\" ในตั้งค่า\n"
              + "3) เข้าโลก รอข้อความ [ITS] ในแชท แล้วพิมพ์ /its:termux เลือกโหมด Normal\n4) ไฟล์ที่ได้อยู่ที่ Download/ITS", 15, false);
        text(l, "บันทึกล่าสุด", 17, true);
        final TextView log = text(l, "", 12, false);
        log.setTypeface(Typeface.MONOSPACE);
        button(l, "อ่านข้อมูลแอปอีกครั้ง").setOnClickListener(v -> showInfo(false));
        h.post(new Runnable() {
            @Override public void run() {
                boolean on = CompanionService.running;
                status.setText(on ? (CompanionService.connected ? "● ทำงานอยู่ — เกมเชื่อมต่อแล้ว" : "● ทำงานอยู่ — รอเกมเชื่อมต่อ") : "○ หยุดอยู่");
                toggle.setText(on ? "หยุด" : "เริ่ม");
                synchronized (CompanionService.LOG) {
                    int from = Math.max(0, CompanionService.LOG.size() - 12);
                    log.setText(android.text.TextUtils.join("\n", CompanionService.LOG.subList(from, CompanionService.LOG.size())));
                }
                h.postDelayed(this, 1000);
            }
        });
    }
}
